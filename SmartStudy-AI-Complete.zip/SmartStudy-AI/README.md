# SmartStudy AI

**Building AI course project**

SmartStudy AI is a student-focused study planning prototype. It helps learners organize tasks, track study progress, and identify topics they may want to revise using transparent, simple recommendation rules.

## Features

- Dashboard with study hours, completed tasks, topics to review, and progress.
- Study planner to add tasks with course, deadline, estimated hours, and priority.
- Rule-based recommendations that consider deadlines, priority, and effort.
- Topic confidence tracker with a 1–5 self-rating.
- Insights view with completion rate, planned hours, average confidence, and revision topics.
- Responsive layout for desktop and mobile.
- Browser `localStorage` persistence; no account or server required.

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser.

No build tools or dependencies are required. The Google Fonts import is optional; the interface falls back to system fonts if offline.

## How the recommendation logic works

Pending tasks are sorted using a transparent heuristic based on due-date urgency, priority, and estimated hours. Topics rated 1 or 2 are flagged for review. This is a rule-based educational aid, not a trained or validated machine-learning model.

## Data and privacy

The prototype stores entries in the current browser using `localStorage`. Do not enter sensitive personal information. Clearing the browser's site data removes saved entries. The app does not transmit data to a server.

## Limitations

- Recommendations are heuristic and may not reflect actual learning needs.
- Confidence ratings are self-reported and are not an objective assessment.
- The prototype does not predict grades, guarantee exam outcomes, or replace instructors.
- Data remains on the device/browser and is not synchronized across devices.
- The project has not been clinically, pedagogically, or scientifically validated.

## Future work

- Optional account system and secure synchronization.
- Calendar integration and user-controlled reminders.
- Practice quizzes and topic-level performance tracking.
- Urdu and English interface support.
- Evaluation with consenting student volunteers and comparison against a simple baseline.
- Accessibility and usability testing.

## Acknowledgments

- Inspired by the Building AI course by Reaktor and the University of Helsinki.
- This is an original prototype concept and implementation prepared for learning purposes.
- No third-party datasets or media assets are bundled. Google Fonts is loaded from Google Fonts when online.
