const $ = (id) => document.getElementById(id);
const STORAGE_KEY = "smartstudy-ai-v1";
const today = new Date();
const isoToday = new Date(today.getTime() - today.getTimezoneOffset()*60000).toISOString().slice(0,10);
$("todayLabel").textContent = today.toLocaleDateString(undefined,{weekday:"short",month:"short",day:"numeric",year:"numeric"});
$("taskDate").min = isoToday;
$("taskDate").value = isoToday;

const seed = {
  tasks:[
    {id:1,title:"Review neural network basics",course:"Artificial Intelligence",date:isoToday,hours:1.5,priority:"High",done:false},
    {id:2,title:"Practice JavaScript arrays",course:"Web Development",date:isoToday,hours:1,priority:"Medium",done:false},
    {id:3,title:"Read about logistic regression",course:"Machine Learning",date:addDays(2),hours:2,priority:"Medium",done:false},
    {id:4,title:"Prepare HCI assignment outline",course:"Human Computer Interaction",date:addDays(3),hours:1,priority:"Low",done:true}
  ],
  topics:[
    {id:1,name:"Neural networks",course:"Artificial Intelligence",confidence:2},
    {id:2,name:"Logistic regression",course:"Machine Learning",confidence:3},
    {id:3,name:"JavaScript fundamentals",course:"Web Development",confidence:4},
    {id:4,name:"Human-computer interaction",course:"HCI",confidence:3}
  ]
};
function addDays(n){const d=new Date();d.setDate(d.getDate()+n);return new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10)}
function load(){try{return JSON.parse(localStorage.getItem(STORAGE_KEY))||structuredClone(seed)}catch{return structuredClone(seed)}}
let state=load();
function save(){localStorage.setItem(STORAGE_KEY,JSON.stringify(state));render()}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function dateObj(s){return new Date(s+"T12:00:00")}
function dateLabel(s){return dateObj(s).toLocaleDateString(undefined,{month:"short",day:"numeric"})}
function remainingDays(s){return Math.ceil((dateObj(s)-dateObj(isoToday))/86400000)}
function recommendationScore(t){const days=remainingDays(t.date);const urgency=days<0?12:days===0?10:days===1?7:Math.max(1,6-days*.5);const priority=t.priority==="High"?3:t.priority==="Medium"?2:1;return urgency+priority+t.hours*.35}
function recommendations(){return state.tasks.filter(t=>!t.done).sort((a,b)=>recommendationScore(b)-recommendationScore(a)).slice(0,3)}
function renderDashboard(){
 const done=state.tasks.filter(t=>t.done), total=state.tasks.length;
 const weekStart=new Date();weekStart.setDate(weekStart.getDate()-6);weekStart.setHours(0,0,0,0);
 const hours=done.reduce((sum,t)=>sum+(t.hours||0),0);
 $("weekHours").innerHTML=hours.toFixed(1)+' <small>hrs</small>';
 $("completedCount").textContent=done.length;
 $("reviewCount").textContent=state.topics.filter(t=>t.confidence<=2).length;
 const pct=total?Math.round(done.length/total*100):0;
 $("progressPercent").textContent=pct+"%";
 $("progressRing").style.background=`conic-gradient(var(--purple) ${pct*3.6}deg,#eeedf6 0deg)`;
 const rec=recommendations();
 $("focusList").innerHTML=rec.length?rec.map((t,i)=>`<div class="focus-item"><div class="focus-symbol">${["✦","◷","▤"][i]}</div><div class="focus-info"><strong>${esc(t.title)}</strong><small>${esc(t.course)} · Due ${dateLabel(t.date)}</small></div><span class="focus-time">${t.hours}h</span></div>`).join(""):'<div class="empty-state">No pending tasks. Add a task to get a study suggestion.</div>';
 const upcoming=state.tasks.filter(t=>!t.done).sort((a,b)=>a.date.localeCompare(b.date)).slice(0,4);
 $("upcomingList").innerHTML=upcoming.length?upcoming.map(t=>`<div class="upcoming-row"><div class="date-box"><strong>${dateObj(t.date).getDate()}</strong><small>${dateObj(t.date).toLocaleDateString(undefined,{month:"short"})}</small></div><div class="task-main"><strong>${esc(t.title)}</strong><small>${esc(t.course)} · ${t.hours} hour${t.hours===1?"":"s"}</small></div><span class="priority ${t.priority}">${t.priority}</span></div>`).join(""):'<div class="empty-state">Nothing scheduled. Enjoy the breathing room or add a task.</div>';
}
function renderTasks(){
 const filter=$("taskFilter").value;
 let tasks=[...state.tasks].sort((a,b)=>a.date.localeCompare(b.date));
 if(filter==="open")tasks=tasks.filter(t=>!t.done);if(filter==="done")tasks=tasks.filter(t=>t.done);
 $("taskList").innerHTML=tasks.length?tasks.map(t=>`<div class="task-row ${t.done?"done":""}"><input class="task-check" type="checkbox" aria-label="Mark ${esc(t.title)} complete" data-toggle="${t.id}" ${t.done?"checked":""}><div class="task-main"><strong>${esc(t.title)}</strong><small>${esc(t.course)} · Due ${dateLabel(t.date)} · ${t.hours}h</small></div><span class="priority ${t.priority}">${t.priority}</span><button class="delete-btn" data-delete-task="${t.id}" aria-label="Delete task">×</button></div>`).join(""):'<div class="empty-state">No tasks in this view yet.</div>';
 document.querySelectorAll("[data-toggle]").forEach(el=>el.addEventListener("change",()=>{const t=state.tasks.find(x=>x.id===Number(el.dataset.toggle));if(t){t.done=el.checked;save();toast(t.done?"Task completed!":"Task moved back to to-do.")}}));
 document.querySelectorAll("[data-delete-task]").forEach(el=>el.addEventListener("click",()=>{state.tasks=state.tasks.filter(t=>t.id!==Number(el.dataset.deleteTask));save();toast("Task removed.")}));
}
function renderTopics(){
 $("topicGrid").innerHTML=state.topics.length?state.topics.map(t=>`<article class="topic-card"><div class="topic-card-top"><div><h3>${esc(t.name)}</h3><small>${esc(t.course)}</small></div><button class="delete-btn" data-delete-topic="${t.id}" aria-label="Delete topic">×</button></div><div class="confidence-label"><span>My confidence</span><strong>${["","Low","Developing","Good","Strong","Expert"][t.confidence]||"Low"}</strong></div><input class="confidence-slider" type="range" min="1" max="5" value="${t.confidence}" data-confidence="${t.id}" aria-label="Confidence for ${esc(t.name)}"><div class="confidence-scale"><span>Need help</span><span>Very confident</span></div></article>`).join(""):'<div class="empty-state">Add a topic to start tracking your confidence.</div>';
 document.querySelectorAll("[data-confidence]").forEach(el=>el.addEventListener("input",()=>{const t=state.topics.find(x=>x.id===Number(el.dataset.confidence));if(t){t.confidence=Number(el.value);const label=el.parentElement.querySelector(".confidence-label strong");label.textContent=["","Low","Developing","Good","Strong","Expert"][t.confidence];saveQuietly()}}));
 document.querySelectorAll("[data-delete-topic]").forEach(el=>el.addEventListener("click",()=>{state.topics=state.topics.filter(t=>t.id!==Number(el.dataset.deleteTopic));save();toast("Topic removed.")}));
}
function saveQuietly(){localStorage.setItem(STORAGE_KEY,JSON.stringify(state));renderStatsOnly()}
function renderInsights(){
 const total=state.tasks.reduce((s,t)=>s+t.hours,0),done=state.tasks.filter(t=>t.done).length;
 $("plannedHours").textContent=total.toFixed(1)+"h";
 $("completionRate").textContent=(state.tasks.length?Math.round(done/state.tasks.length*100):0)+"%";
 const avg=state.topics.length?state.topics.reduce((s,t)=>s+t.confidence,0)/state.topics.length:0;
 $("avgConfidence").textContent=state.topics.length?avg.toFixed(1)+"/5":"—";
 const topics=[...state.topics].sort((a,b)=>a.confidence-b.confidence);
 $("insightTopics").innerHTML=topics.length?topics.map(t=>`<div class="insight-topic-row"><div class="topic-mini">◈</div><div class="insight-topic-info"><strong>${esc(t.name)}</strong><small>${esc(t.course)}</small></div><span class="confidence-badge ${t.confidence>=4?"high":""}">${["","Low","Developing","Good","Strong","Expert"][t.confidence]}</span></div>`).join(""):'<div class="empty-state">Add topics to see revision insights.</div>';
}
function renderStatsOnly(){renderInsights();$("reviewCount").textContent=state.topics.filter(t=>t.confidence<=2).length}
function render(){renderDashboard();renderTasks();renderTopics();renderInsights()}
function toast(msg){const el=$("toast");el.textContent=msg;el.classList.add("show");clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>el.classList.remove("show"),2400)}
function showView(id){document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active",v.id===id));document.querySelectorAll(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.view===id));window.scrollTo({top:0,behavior:"smooth"})}
document.querySelectorAll("[data-view]").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
document.querySelectorAll("[data-goto]").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.goto)));
$("taskForm").addEventListener("submit",e=>{e.preventDefault();state.tasks.push({id:Date.now(),title:$("taskTitle").value.trim(),course:$("taskCourse").value.trim(),date:$("taskDate").value,hours:Number($("taskHours").value),priority:$("taskPriority").value,done:false});e.target.reset();$("taskDate").value=isoToday;$("taskHours").value=1;save();toast("Study task added to your plan.")});
$("topicForm").addEventListener("submit",e=>{e.preventDefault();state.topics.push({id:Date.now(),name:$("topicName").value.trim(),course:$("topicCourse").value.trim(),confidence:2});e.target.reset();save();toast("Topic added. Rate your confidence.")});
$("taskFilter").addEventListener("change",renderTasks);
$("resetBtn").addEventListener("click",()=>{if(confirm("Reset all SmartStudy demo data in this browser?")){state=structuredClone(seed);save();toast("Demo data reset.")}});
render();